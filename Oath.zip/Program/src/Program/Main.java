package Program;

public class Main {

    public static void main(String[] args) {
        System.out.println("Java is the starting point");
        System.out.println("I am so eager to learn it");
        System.out.println("I promise to put my all effort into learning its key concepts");
        System.out.println("and understanding them so well");
        System.out.println("With a growth-mindset i believe,by the end of 2022 i would have gotten a handful of project under my belt");
        System.out.println("So help me GOD");
        System.out.println("Amen!");
    }
    }
